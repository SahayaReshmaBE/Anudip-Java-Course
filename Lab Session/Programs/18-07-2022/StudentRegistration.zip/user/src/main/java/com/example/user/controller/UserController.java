package com.example.user.controller;

import java.util.List;

import org.hibernate.type.MetaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.user.dao.UserDAO;
import com.example.user.entity.User;

@RestController
@RequestMapping(value = {"/user"})

public class UserController {
	@Autowired
	UserDAO userdao;
	
	@GetMapping(value = "/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> getMethodName(@PathVariable("id") int id) {
		
		System.out.println("From id "+id);
		
		User user= userdao.findById(id);
		return new ResponseEntity<User>(user,HttpStatus.OK);
	}
	
	
	@RequestMapping(value ="/test")
	public String getValue() {
		return "Hello i am spring boot";
	}
	
	@DeleteMapping(value = "/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<User> deleteMethod(@PathVariable("id") int id)
	{
		System.out.println(id);
		userdao.delete(id);
		
		return new  ResponseEntity<User>(HttpStatus.OK);
		
	}
	
	@GetMapping(value = "/getData",headers = "Accept=application/json")
	public List<User> getallData()
	{
		List alllist=userdao.listData();
		
		return alllist;
	}
	
	@PutMapping(value = "/update",headers ="Accept=application/json" )
	public ResponseEntity<String> update(@RequestBody User curentuser)
	{
		System.out.println("from update "+curentuser+"," +curentuser.getId());
		userdao.updateRecord(curentuser, curentuser.getId());
		return new  ResponseEntity<String>(HttpStatus.OK);
	}
	
	@PostMapping(value = "/insert",headers ="Accept=application/json")
	public ResponseEntity<Void> insertindData(@RequestBody User user,UriComponentsBuilder ucbuillder)
	{
		System.out.println("inserting .."+user.getFname());
		
		userdao.inserData(user);
		
		return new ResponseEntity<Void>(HttpStatus.CREATED);
		
	}
	

	
	

}
