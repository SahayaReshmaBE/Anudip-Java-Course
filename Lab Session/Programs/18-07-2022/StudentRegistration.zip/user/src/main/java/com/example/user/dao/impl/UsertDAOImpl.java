package com.example.user.dao.impl;


import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.user.dao.UserDAO;
import com.example.user.entity.User;




@Repository
public class UsertDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	

	
	
	
	

	
	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, id);
		return user;
	}







	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.getCurrentSession();
		User deleteuser = findById(id);
		
		session.delete(deleteuser);
		
		System.out.println("Records Deleted");
		Transaction transaction= session.beginTransaction();
		transaction.commit();
		
	}






	






	@Override
	public List<User> listData() {
		Session session =sessionFactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		
		CriteriaQuery<User>  myobj= builder.createQuery(User.class);
		
		Root<User>queryobj = myobj.from(User.class);
		myobj.select(queryobj);
		
		 TypedQuery<User> query= session.createQuery(myobj);
		return query.getResultList();
	}







	@Override
	public User updateRecord(User user, int id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		
		User user1 =  findById(id);
		
		user1.setAddress(user.getAddress());
		
		user1.setFname(user.getFname());
		
		session.update(user1);
		Transaction tx =session.beginTransaction();
		tx.commit();
		
		return user1;
	}







	@Override
	public void inserData(User user) {
	Session session=	sessionFactory.getCurrentSession();
		session.save(user);
		
		Transaction tx =session.beginTransaction();
		tx.commit();
		
		System.out.println("Values are inserted");
	}

	
	

	
	

}
