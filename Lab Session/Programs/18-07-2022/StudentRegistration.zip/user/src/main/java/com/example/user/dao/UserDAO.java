package com.example.user.dao;

import java.util.List;

import com.example.user.entity.User;
public interface UserDAO {

	

	public User findById(int id);
	
	public void delete(int id);
	
	public List<User> listData();
	
	
	public User updateRecord(User user,int id);
	
	public void inserData(User user);

	
}